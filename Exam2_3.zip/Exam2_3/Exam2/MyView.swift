//
//  MyView.swift
//  Exam2
//
//  Created by renl on 2017/11/21.
//  Copyright © 2017年 黄宇. All rights reserved.
//

import UIKit

class MyView: UIView {

    // 缩放比例
    var scale: CGFloat = 0.9
    
    override func draw(_ rect: CGRect) {
        
//        let path = UIBezierPath(ovalIn: CGRect(x: bounds.midX, y: bounds.midY, width: bounds.size.width/2*scale, height: bounds.size.height/2*scale))
//
//        path.lineWidth = 5.0
//        self.backgroundColor = UIColor.clear
//        UIColor.blue.set()
//        path.stroke()
        let image:UIImage? = UIImage(named: "timg.png")
        image?.draw(in: CGRect(x: 0, y: 0, width: 100, height: 100))
    }

}
