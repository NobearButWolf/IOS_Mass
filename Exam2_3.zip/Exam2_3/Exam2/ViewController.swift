//
//  ViewController.swift
//  Exam2
//
//  Created by renl on 2017/11/21.
//  Copyright © 2017年 黄宇. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    let userName = "admin"
    let password_yes = "admin"
    var height:CGFloat = 0
    var flag = false
    
    @IBOutlet weak var feiji: MyView!
    @IBOutlet weak var bottomConstarint: NSLayoutConstraint!
    @IBOutlet weak var user: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBAction func login(_ sender: UIButton) {
        
        let alertY = UIAlertController(title: "登陆成功", message: "登陆成功", preferredStyle: .alert)
        alertY.addAction(UIAlertAction(title: "确定", style: .cancel, handler: nil))
        let alertN = UIAlertController(title: "登陆失败", message: "账号密码错误", preferredStyle: .alert)
        alertN.addAction(UIAlertAction(title: "确定", style: .cancel, handler: nil))
        let alert = UIAlertController(title: "登陆", message: "警告：你的用户名和密码将会通过网络明文传输，可能存在安全隐患，你确定要登陆吗", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "确定", style: .default, handler: { (action) in
            if self.user.text == self.userName && self.password.text == self.password_yes {
                UIView.transition(with: self.view, duration: 3.0, options: .allowAnimatedContent, animations: {
                    let new_xpoint = -100
                    let new_ypoint = -100
                    self.feiji.center = CGPoint(x: new_xpoint, y: new_ypoint)
                },completion: nil)
                self.flag = true
            } else {
                self.flag = false
            }
            self.view.endEditing(true)
        }))
        alert.addAction(UIAlertAction(title: "取消", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
        if flag {
            present(alertY, animated: true, completion: nil)
        } else {
            present(alertN, animated: true, completion: nil)
        }
    }
    @IBAction func clear(_ sender: UIButton) {
        user.text = ""
        password.text = ""
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        // 1.添加键盘显示时的观察者
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: .UIKeyboardDidShow, object: nil)
        
        // 2.添加键盘消失时的观察者
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: .UIKeyboardWillHide, object: nil)
        
        password.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func actionSheet(_ sender: UIButton) {
        let alert = UIAlertController(title: "改变颜色", message: "请选择你希望的背景色！！！", preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "红色", style: .default, handler: { (action) in
            self.view.backgroundColor = UIColor.red
        }))
        
        alert.addAction(UIAlertAction(title: "绿色", style: .default, handler: { (action) in
            self.view.backgroundColor = UIColor.green
        }))
        
        alert.addAction(UIAlertAction(title: "蓝色", style: .default, handler: { (action) in
            self.view.backgroundColor = UIColor.blue
        }))
        
        alert.addAction(UIAlertAction(title: "白色", style: .destructive, handler: { (action) in
            self.view.backgroundColor = UIColor.white
        }))
        
        alert.addAction(UIAlertAction(title: "取消", style: .cancel, handler: nil))
        
        present(alert, animated: true, completion: nil)
    }
    
    // 1.当键盘开始显示的时候调用
    @objc func keyboardWillShow(notification:NSNotification) {
        adjustingHeight(show: true, notification: notification)
    }
    
    // 2.当键盘消失的时候调用
    @objc func keyboardWillHide(notification:NSNotification) {
        adjustingHeight(show: false, notification: notification)
    }
    
    // 3.设置键盘的属性
    func adjustingHeight(show:Bool, notification:NSNotification) {
        // 3.1.在字典中获取通知信息
        var userInfo = notification.userInfo!
        
        //height用来记录软键盘的高度
        if(height == 0){
            // 3.2.获取键盘的Frame
            let keyboardFrame:CGRect = (userInfo[UIKeyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
            height = keyboardFrame.height
        }
        //改变textField的bottom约束
        bottomConstarint.constant = show ? height+10:10
    }
    // 重写 viewWillDisappear 方法
    override func viewWillDisappear(_ animated: Bool) {
        // 1.删除键盘显示时的观察者
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        // 2.删除键盘隐藏时的观察者
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    //当点击外部，软键盘消失
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //收起键盘
        textField.resignFirstResponder()
        //打印出文本框中的值
//        print(textField.text)
        return true;
    }

}

